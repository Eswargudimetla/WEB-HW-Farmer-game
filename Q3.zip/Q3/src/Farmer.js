import { clamp } from "./utils.js";

/**
 * @class Farmer
 * @classdesc Player-controlled entity (movement, brief i-frames on hit).
 */
export class Farmer {
  /**
   * @param {number} x
   * @param {number} y
   */
  constructor(x, y) {
    this.x = x; this.y = y; this.w = 34; this.h = 34;
    this.baseSpeed = 260;
    this.speed = this.baseSpeed;
    this.vx = 0; this.vy = 0;
    this.color = "#8b5a2b";
    this.iframes = 0;
  }

  /**
   * Update input-derived velocity.
   * @param {{keys:Set<string>}} input
   */
  handleInput(input) {
    const L = input.keys.has("ArrowLeft"), R = input.keys.has("ArrowRight");
    const U = input.keys.has("ArrowUp"),   D = input.keys.has("ArrowDown");
    this.vx = (R - L) * this.speed;
    this.vy = (D - U) * this.speed;
  }

  /**
   * Move and prevent passing static obstacles by reverting on collision.
   * @param {number} dt
   * @param {import('./Game.js').Game} game
   */
  update(dt, game) {
    this.iframes = Math.max(0, this.iframes - dt);
    const oldX = this.x, oldY = this.y;

    this.x = clamp(this.x + this.vx * dt, 0, game.bounds.w - this.w);
    this.y = clamp(this.y + this.vy * dt, 0, game.bounds.h - this.h);

    const hit = game.staticObstacles.some(o => game.aabb(this, o));
    if (hit) { this.x = oldX; this.y = oldY; }
  }

  /** @param {CanvasRenderingContext2D} ctx */
  draw(ctx) {
    ctx.fillStyle = this.iframes > 0 ? "#f59e0b" : this.color;
    ctx.fillRect(this.x, this.y, this.w, this.h);
    ctx.fillStyle = "#c28e0e";
    ctx.fillRect(this.x + 4, this.y - 6, this.w - 8, 8);        // hat brim
    ctx.fillRect(this.x + 10, this.y - 18, this.w - 20, 12);    // hat top
  }
}
