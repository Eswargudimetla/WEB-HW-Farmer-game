/**
 * @class PowerUp
 * @classdesc Rotating pickup: 'speed' boosts velocity, 'scythe' gives harvest aura.
 */
export class PowerUp {
  /**
   * @param {number} x
   * @param {number} y
   * @param {"speed"|"scythe"} type
   */
  constructor(x, y, type = "speed") {
    this.x = x; this.y = y; this.w = 18; this.h = 18;
    this.type = type;
    this.spin = Math.random() * Math.PI * 2;
    this.dead = false;
  }
  /** @param {number} dt */
  update(dt) { this.spin += dt * 4; }
  /** @param {CanvasRenderingContext2D} ctx */
  draw(ctx) {
    const r = this.w / 2;
    ctx.save();
    ctx.translate(this.x + r, this.y + r);
    ctx.rotate(this.spin);
    if (this.type === "speed") {
      ctx.fillStyle = "#60a5fa";
      ctx.fillRect(-r, -r, this.w, this.h);
    } else {
      ctx.strokeStyle = "#f59e0b"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
  }
}
