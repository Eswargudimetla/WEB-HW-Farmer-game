/** @enum {string} */
export const State = Object.freeze({
  MENU: "MENU",
  PLAYING: "PLAYING",
  PAUSED: "PAUSED",
  GAME_OVER: "GAME_OVER",
  WIN: "WIN",
});

/** @param {number} v @param {number} lo @param {number} hi */
export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/** Axis-aligned box overlap */
export const aabb = (a, b) =>
  a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

/** @param {number} a @param {number} b @param {number} t [0..1] */
export const lerp = (a, b, t) => a + (b - a) * t;

/** @param {number} min @param {number} max */
export const rnd = (min, max) => Math.random() * (max - min) + min;
