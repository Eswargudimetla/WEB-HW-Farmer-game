import { Farmer } from "./Farmer.js";
import { Crop } from "./Crop.js";
import { Scarecrow, Crow } from "./Obstacle.js";
import { PowerUp } from "./PowerUp.js";
import { State, clamp, aabb, lerp, rnd } from "./utils.js";

/**
 * @class Game
 * @classdesc Orchestrates loop, entities, scoring, difficulty, and HUD.
 */
export class Game {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {{scoreEl?:HTMLElement,timeEl?:HTMLElement,goalEl?:HTMLElement,statusEl?:HTMLElement,powerEl?:HTMLElement,levelEl?:HTMLElement}} hud
   */
  constructor(canvas, hud = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");

    // canvas bounds shared with entities
    this.bounds = { w: canvas.width, h: canvas.height };

    // expose aabb to entities that need it
    this.aabb = aabb;

    // state
    this.state = State.MENU;
    this.timeLen = 60;        // seconds
    this.goal = 60;           // target points
    this.score = 0;
    this.timeLeft = this.timeLen;
    this.level = 1;

    // world
    this.player = new Farmer(this.bounds.w / 2 - 17, this.bounds.h - 80);
    /** @type {Crop[]} */ this.crops = [];
    /** @type {Scarecrow[]} */ this.staticObstacles = [new Scarecrow(200, 220), new Scarecrow(650, 160)];
    /** @type {Crow[]} */ this.crows = [];
    /** @type {PowerUp[]} */ this.powerups = [];

    // spawners
    this._accumCrop = 0;
    this._accumCrow = 0;
    this._accumPower = 0;
    this.spawnEveryBase = 0.9;
    this.crowEveryBase  = 6.0;
    this.powerEveryBase = 8.0;

    // power state
    this.activePower = null;  // 'speed'|'scythe'|null
    this.powerTime = 0;
    this.scytheRadius = 0;

    // time & loop
    this.lastTime = 0;

    // HUD refs
    this.hud = {
      scoreEl: hud.scoreEl || null,
      timeEl: hud.timeEl || null,
      goalEl: hud.goalEl || null,
      statusEl: hud.statusEl || null,
      powerEl: hud.powerEl || null,
      levelEl: hud.levelEl || null,
    };
    if (this.hud.goalEl) this.hud.goalEl.textContent = String(this.goal);

    // Input
    this.input = new Input(this); // defined below

    // Resize handler with .bind(this)
    this.onResize = this.onResize.bind(this);
    window.addEventListener("resize", this.onResize);
    // Q1b: .bind(this) ensures `this` is Game when browser invokes onResize; storing it lets us remove later.

    // RAF loop as arrow → lexical this
    // Q1c (RAF): requestAnimationFrame would call with `this=window`. Arrow captures Game instance.
    this.tick = (ts) => {
      const dt = Math.min((ts - this.lastTime) / 1000, 0.033);
      this.lastTime = ts;
      this.update(dt);
      this.render();
      requestAnimationFrame(this.tick);
    };

    // splash HUD
    this.syncUI();
  }

  /** Keep canvas size policy consistent (fixed for this assignment). */
  onResize() { /* noop (could support DPR/resize here) */ }

  /** Start/resume the game. */
  start() {
    if (this.state === State.MENU || this.state === State.GAME_OVER || this.state === State.WIN) {
      this.reset();
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "Playing…";
      requestAnimationFrame(this.tick);
    } else if (this.state === State.PAUSED) {
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "Playing…";
    }
  }

  /** Back to menu-ready state. */
  reset() {
    this.state = State.MENU;
    this.player = new Farmer(this.bounds.w / 2 - 17, this.bounds.h - 80);
    this.crops.length = 0;
    this.staticObstacles = [new Scarecrow(200, 220), new Scarecrow(650, 160)];
    this.crows.length = 0;
    this.powerups.length = 0;
    this.score = 0;
    this.timeLeft = this.timeLen;
    this.level = 1;
    this.activePower = null;
    this.powerTime = 0;
    this.scytheRadius = 0;
    this._accumCrop = 0;
    this._accumCrow = 0;
    this._accumPower = 0;
    this.lastTime = performance.now();
    this.syncUI();
    if (this.hud.statusEl) this.hud.statusEl.textContent = "Menu";
  }

  /** Pause/unpause. */
  togglePause() {
    if (this.state === State.PLAYING) {
      this.state = State.PAUSED;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "Paused";
    } else if (this.state === State.PAUSED) {
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "Playing…";
    }
  }

  /** Difficulty factor 0→1 over round. */
  getDifficulty() {
    const elapsed = this.timeLen - this.timeLeft;
    return clamp(elapsed / this.timeLen, 0, 1);
  }

  /** Update HUD text. */
  syncUI() {
    if (this.hud.scoreEl) this.hud.scoreEl.textContent = String(this.score);
    if (this.hud.timeEl)  this.hud.timeEl.textContent  = Math.ceil(this.timeLeft);
    if (this.hud.goalEl)  this.hud.goalEl.textContent  = String(this.goal);
    if (this.hud.powerEl) this.hud.powerEl.textContent = this.activePower
      ? `${this.activePower} (${Math.ceil(this.powerTime)}s)` : "—";
    if (this.hud.levelEl) this.hud.levelEl.textContent = String(this.level);
  }

  /** Spawn a weighted random crop. */
  spawnCrop() {
    const r = Math.random();
    const type = r < 0.6 ? "wheat" : r < 0.9 ? "pumpkin" : "golden";
    const gx = Math.floor(Math.random() * ((this.bounds.w - 60) / 30)) * 30 + 30;
    const gy = Math.floor(Math.random() * ((this.bounds.h - 60) / 30)) * 30 + 30;
    this.crops.push(new Crop(gx, gy, type));
  }

  /** Spawn a crow with a loose aim toward center. */
  spawnCrow() {
    const x = Math.random() < 0.5 ? -20 : this.bounds.w + 20;
    const y = rnd(40, this.bounds.h - 40);
    const c = new Crow(x, y);
    const cx = this.bounds.w / 2 - c.x, cy = this.bounds.h / 2 - c.y, len = Math.hypot(cx, cy) || 1;
    const speed = rnd(70, 120) + this.getDifficulty() * 60;
    c.vx = (cx / len) * speed + rnd(-40, 40);
    c.vy = (cy / len) * speed + rnd(-30, 30);
    this.crows.push(c);
  }

  /** Spawn a speed/scythe power-up. */
  spawnPowerUp() {
    const type = Math.random() < 0.5 ? "speed" : "scythe";
    const x = rnd(40, this.bounds.w - 40), y = rnd(40, this.bounds.h - 40);
    this.powerups.push(new PowerUp(x, y, type));
  }

  /** Apply a power-up and set timers. */
  applyPowerUp(type) {
    if (type === "speed") {
      this.activePower = "speed";
      this.powerTime = 6;
      this.player.speed = this.player.baseSpeed * 1.7;
      this.scytheRadius = 0;
    } else {
      this.activePower = "scythe";
      this.powerTime = 6;
      this.player.speed = this.player.baseSpeed;
      this.scytheRadius = 100;
    }
    this.syncUI();
  }

  /** Countdown effect of current power-up. */
  updatePowerUpTimers(dt) {
    if (!this.activePower) return;
    this.powerTime -= dt;
    if (this.powerTime <= 0) {
      this.activePower = null;
      this.player.speed = this.player.baseSpeed;
      this.scytheRadius = 0;
    }
  }

  /** Main update step. */
  update(dt) {
    if (this.state !== State.PLAYING) return;

    // timer
    this.timeLeft = clamp(this.timeLeft - dt, 0, this.timeLen);
    if (this.timeLeft <= 0) {
      this.state = (this.score >= this.goal) ? State.WIN : State.GAME_OVER;
      if (this.hud.statusEl) this.hud.statusEl.textContent = (this.state === State.WIN) ? "You Win!" : "Game Over";
      this.syncUI();
      return;
    }

    // difficulty
    const D = this.getDifficulty();
    const cropEvery  = lerp(this.spawnEveryBase, 0.25, D);
    const crowEvery  = lerp(this.crowEveryBase,  2.2,  D);
    const powerEvery = lerp(this.powerEveryBase, 4.0,  D);
    this.level = 1 + Math.floor(D * 4);

    // player
    this.player.handleInput(this.input);
    // Q1c (method reference): method-call form keeps `this` inside Farmer.update as Farmer instance.
    this.player.update(dt, this);

    // spawns
    this._accumCrop += dt;
    while (this._accumCrop >= cropEvery) { this._accumCrop -= cropEvery; this.spawnCrop(); }

    this._accumCrow += dt;
    while (this._accumCrow >= crowEvery) {
      this._accumCrow -= crowEvery;
      const maxCrows = Math.floor(1 + D * 4);
      if (this.crows.length < maxCrows) this.spawnCrow();
    }

    this._accumPower += dt;
    while (this._accumPower >= powerEvery) {
      this._accumPower -= powerEvery;
      if (this.powerups.length < 2) this.spawnPowerUp();
    }

    // crop collection (touch)
    const touchCollected = this.crops.filter(c => aabb(this.player, c));
    if (touchCollected.length) {
      touchCollected.forEach(c => c.dead = true);
      this.score += touchCollected.reduce((s, c) => s + c.points, 0);
    }

    // scythe aura auto-collect
    if (this.activePower === "scythe" && this.scytheRadius > 0) {
      const px = this.player.x + this.player.w / 2, py = this.player.y + this.player.h / 2;
      this.crops.forEach(c => {
        const cx = c.x + c.w / 2, cy = c.y + c.h / 2;
        const d = Math.hypot(px - cx, py - cy);
        if (d <= this.scytheRadius) { c.dead = true; this.score += c.points; }
      });
    }

    // power-up pickups
    this.powerups.forEach(p => { if (aabb(p, this.player)) { p.dead = true; this.applyPowerUp(p.type); } });

    // advance entities
    this.crows.forEach(c => c.update(dt, this));
    this.crops.forEach(c => c.update(dt, this));
    this.powerups.forEach(p => p.update(dt, this));

    // prune
    this.crops    = this.crops.filter(c => !c.dead);
    this.powerups = this.powerups.filter(p => !p.dead);

    if (this.score >= this.goal) {
      this.state = State.WIN;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "You Win!";
    }

    this.updatePowerUpTimers(dt);
    this.syncUI();
  }

  /** Draw board and entities. */
  render() {
    const ctx = this.ctx;
    if (!ctx) return;

    ctx.clearRect(0, 0, this.bounds.w, this.bounds.h);

    // background grid
    ctx.fillStyle = "#dff0d5";
    ctx.fillRect(0, 0, this.bounds.w, this.bounds.h);
    ctx.strokeStyle = "#c7e0bd";
    ctx.lineWidth = 1;
    for (let y = 30; y < this.bounds.h; y += 30) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.bounds.w, y); ctx.stroke(); }
    for (let x = 30; x < this.bounds.w; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.bounds.h); ctx.stroke(); }

    // draw entities
    this.crops.forEach(c => c.draw(ctx));
    this.powerups.forEach(p => p.draw(ctx));
    this.crows.forEach(c => c.draw(ctx));
    this.staticObstacles.forEach(o => o.draw(ctx));
    this.player.draw(ctx);

    // scythe aura ring
    if (this.activePower === "scythe" && this.scytheRadius > 0) {
      const px = this.player.x + this.player.w / 2, py = this.player.y + this.player.h / 2;
      ctx.strokeStyle = "rgba(245, 158, 11, 0.45)";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px, py, this.scytheRadius, 0, Math.PI * 2); ctx.stroke();
    }

    // state labels
    ctx.fillStyle = "#333";
    ctx.font = "16px system-ui, sans-serif";
    if (this.state === State.MENU) {
      ctx.fillText("Press Start to play", 20, 28);
    } else if (this.state === State.PAUSED) {
      ctx.fillText("Paused (press P to resume)", 20, 28);
    } else if (this.state === State.GAME_OVER) {
      ctx.fillText("Time up! Press Reset to return to Menu", 20, 28);
    } else if (this.state === State.WIN) {
      ctx.fillText("Harvest complete! Press Reset for another round", 20, 28);
    }
  }

  /** Clean up DOM listeners. */
  dispose() {
    this.input.dispose();
    window.removeEventListener("resize", this.onResize);
  }
}

/**
 * @class Input
 * @classdesc Keyboard input manager with bound handlers (removable).
 */
class Input {
  /** @param {Game} game */
  constructor(game) {
    this.game = game;
    this.keys = new Set();
    // Q1b: .bind(this) so inside handlers `this` is Input; stored refs let us remove them.
    this._onKeyDown = this.onKeyDown.bind(this);
    this._onKeyUp   = this.onKeyUp.bind(this);
    window.addEventListener("keydown", this._onKeyDown);
    window.addEventListener("keyup", this._onKeyUp);
  }
  /** @param {KeyboardEvent} e */
  onKeyDown(e) {
    if (e.key === "p" || e.key === "P") this.game.togglePause();
    this.keys.add(e.key);
  }
  /** @param {KeyboardEvent} e */
  onKeyUp(e) { this.keys.delete(e.key); }
  /** remove listeners */
  dispose() {
    window.removeEventListener("keydown", this._onKeyDown);
    window.removeEventListener("keyup", this._onKeyUp);
  }
}
