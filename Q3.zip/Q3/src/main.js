import { Game } from "./Game.js";

/** Wire DOM → Game and start/stop buttons. */
const canvas = /** @type {HTMLCanvasElement} */ (document.getElementById("game"));
const hud = {
  scoreEl: document.getElementById("score"),
  timeEl:  document.getElementById("time"),
  goalEl:  document.getElementById("goal"),
  statusEl:document.getElementById("status"),
  powerEl: document.getElementById("powerup"),
  levelEl: document.getElementById("level"),
};

const game = new Game(canvas, hud);

// Q1a: arrow callbacks are ideal for simple UI actions (no need to remove by identity).
document.getElementById("btnStart").addEventListener("click", () => game.start());
document.getElementById("btnReset").addEventListener("click", () => game.reset());

// for quick console access if you want to test
window.__farmerGame = game;
