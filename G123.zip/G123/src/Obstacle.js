import { clamp, rnd } from "./utils.js";

/**
 * @class Scarecrow
 * @classdesc Static obstacle (blocks movement).
 */
export class Scarecrow {
  constructor(x, y) { this.x = x; this.y = y; this.w = 26; this.h = 46; }
  /** @param {CanvasRenderingContext2D} ctx */
  draw(ctx) {
    const { x, y, w, h } = this;
    ctx.fillStyle = "#9b7653";
    ctx.fillRect(x + w / 2 - 3, y, 6, h); // pole
    ctx.fillStyle = "#c28e0e";
    ctx.beginPath(); ctx.arc(x + w / 2, y + 10, 10, 0, Math.PI * 2); ctx.fill(); // head
    ctx.strokeStyle = "#6b4f2a"; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(x, y + 18); ctx.lineTo(x + w, y + 18); ctx.stroke(); // arms
  }
}

/**
 * @class Crow
 * @classdesc Moving hazard; penalizes on contact, then cools down.
 */
export class Crow {
  constructor(x, y) {
    this.x = x; this.y = y; this.w = 22; this.h = 16;
    this.vx = rnd(-80, 80);
    this.vy = rnd(-60, 60);
    this.cooldown = 0;
  }
  /**
   * @param {number} dt
   * @param {import('./Game.js').Game} game
   */
  update(dt, game) {
    this.cooldown = Math.max(0, this.cooldown - dt);
    // wander & bounce in bounds
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    if (this.x < 0 || this.x + this.w > game.bounds.w) {
      this.vx *= -1; this.x = clamp(this.x, 0, game.bounds.w - this.w);
    }
    if (this.y < 0 || this.y + this.h > game.bounds.h) {
      this.vy *= -1; this.y = clamp(this.y, 0, game.bounds.h - this.h);
    }

    // collide with player
    if (game.aabb(this, game.player) && this.cooldown <= 0 && game.player.iframes <= 0) {
      game.timeLeft = Math.max(0, game.timeLeft - 3);
      game.score = Math.max(0, game.score - 2);
      game.player.iframes = 1.0;
      this.cooldown = 0.8;
      // nudge crow away
      this.vx = rnd(-120, 120);
      this.vy = rnd(-90, 90);
      game.syncUI();
    }
  }
  /** @param {CanvasRenderingContext2D} ctx */
  draw(ctx) {
    ctx.fillStyle = "#1f2937";
    ctx.fillRect(this.x, this.y, this.w, this.h);
    ctx.fillStyle = "#111827";
    ctx.fillRect(this.x + 3, this.y + 3, 4, 4);
  }
}
