import { clamp } from "./utils.js";

/**
 * Player with 4x4 sprite sheet.
 * Rows: 0=down, 1=left, 2=right, 3=up. Cols: 0..3.
 */
export class Farmer {
  constructor(x, y) {
    this.x = x; this.y = y; this.w = 34; this.h = 34;
    this.baseSpeed = 260;
    this.speed = this.baseSpeed;
    this.vx = 0; this.vy = 0;
    this.iframes = 0;

    // sprite
    this.sprite = new Image();
    this.spriteLoaded = false;
    this.sprite.src = "./sprites/farmer.png";
    this.sprite.onload = () => { this.spriteLoaded = true; };

    // sheet info
    this.sheetCols = 4;
    this.sheetRows = 4;
    this.srcCell = 64;

    // animation state
    this.animCol = 0;     // 0..3
    this.animRow = 0;     // 0=down,1=left,2=right,3=up
    this.frameTimer = 0;  // accumulates seconds
    this.animFps = 10;    // frames per second when moving
    this.lastFacing = "down";
  }

  handleInput(input) {
    const L = input.keys.has("ArrowLeft"), R = input.keys.has("ArrowRight");
    const U = input.keys.has("ArrowUp"),   D = input.keys.has("ArrowDown");
    this.vx = (R - L) * this.speed;
    this.vy = (D - U) * this.speed;

    // ---- Stable facing (dominant axis) ----
    const ax = Math.abs(this.vx), ay = Math.abs(this.vy);
    const EPS = 1; // tiny threshold to avoid jitter
    if (ax > EPS || ay > EPS) {
      if (ax >= ay) this.lastFacing = (this.vx < 0) ? "left" : "right";
      else          this.lastFacing = (this.vy < 0) ? "up"   : "down";
    }
    this.animRow =
      this.lastFacing === "down"  ? 0 :
      this.lastFacing === "left"  ? 1 :
      this.lastFacing === "right" ? 2 : 3;
  }

  update(dt, game) {
    this.iframes = Math.max(0, this.iframes - dt);

    // movement with bounds & obstacle blocking
    const oldX = this.x, oldY = this.y;
    this.x = clamp(this.x + this.vx * dt, 0, game.bounds.w - this.w);
    this.y = clamp(this.y + this.vy * dt, 0, game.bounds.h - this.h);
    const hit = game.staticObstacles.some(o => game.aabb(this, o));
    if (hit) { this.x = oldX; this.y = oldY; }

    // ---- Fixed-step animation clock ----
    const moving = Math.abs(this.vx) > 1 || Math.abs(this.vy) > 1;
    if (moving) {
      const step = 1 / this.animFps;     // seconds per frame
      this.frameTimer += dt;
      while (this.frameTimer >= step) {
        this.frameTimer -= step;
        this.animCol = (this.animCol + 1) % this.sheetCols; // advance exactly 1 frame
      }
    } else {
      // idle: hold frame 0, keep last facing
      this.animCol = 0;
      this.frameTimer = 0;
    }
  }

  draw(ctx) {
    if (this.spriteLoaded) {
      const sx = this.animCol * this.srcCell;
      const sy = this.animRow * this.srcCell;
      const sw = this.srcCell, sh = this.srcCell;

      // draw centered over collision box (no weird scaling → fewer artifacts)
      const dw = this.w, dh = this.h;
      const dx = this.x, dy = this.y;

      // (Optional) snap to integers to avoid subpixel shimmer
      ctx.drawImage(this.sprite, sx, sy, sw, sh, Math.round(dx), Math.round(dy), dw, dh);

      if (this.iframes > 0) {
        ctx.fillStyle = "rgba(245,158,11,0.25)";
        ctx.fillRect(Math.round(dx), Math.round(dy), dw, dh);
      }
    } else {
      // fallback box while image loads
      ctx.fillStyle = this.iframes > 0 ? "#f59e0b" : "#8b5a2b";
      ctx.fillRect(this.x, this.y, this.w, this.h);
      ctx.fillStyle = "#c28e0e";
      ctx.fillRect(this.x + 4, this.y - 6, this.w - 8, 8);
      ctx.fillRect(this.x + 10, this.y - 18, this.w - 20, 12);
    }
  }
}
