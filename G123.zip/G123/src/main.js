import { Game } from "./Game.js";

const canvas = /** @type {HTMLCanvasElement} */ (document.getElementById("game"));
const hud = {
  scoreEl: document.getElementById("score"),
  timeEl:  document.getElementById("time"),
  goalEl:  document.getElementById("goal"),
  statusEl:document.getElementById("status"),
  powerEl: document.getElementById("powerup"),
  levelEl: document.getElementById("level"),
};

const game = new Game(canvas, hud);

// Wait for config.json to load (G3)
await game.init();

document.getElementById("btnStart").addEventListener("click", () => game.start());
document.getElementById("btnReset").addEventListener("click", () => game.reset());

window.__farmerGame = game;
