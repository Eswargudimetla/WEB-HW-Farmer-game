
/**
 * @class Crop
 * @classdesc Collectible with type & point value.
 */
export class Crop {
  /**
   * @param {number} x
   * @param {number} y
   * @param {"wheat"|"pumpkin"|"golden"} type
   */
  constructor(x, y, type = "wheat") {
    this.x = x; this.y = y; this.w = 20; this.h = 26;
    this.type = type;
    this.points = type === "wheat" ? 1 : type === "pumpkin" ? 3 : 5;
    this.sway = Math.random() * Math.PI * 2;
    this.dead = false;
  }

  /** @param {number} dt */
  update(dt) { this.sway += dt * 2; }

  /** @param {CanvasRenderingContext2D} ctx */
  draw(ctx) {
    const { x, y, w, h } = this;
    // stem
    ctx.strokeStyle = "#2f7d32";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x + w / 2, y + h);
    ctx.quadraticCurveTo(x + w / 2 + Math.sin(this.sway) * 3, y + h / 2, x + w / 2, y);
    ctx.stroke();
    // head by type
    if (this.type === "wheat") ctx.fillStyle = "#facc15";
    else if (this.type === "pumpkin") ctx.fillStyle = "#f97316";
    else ctx.fillStyle = "#fde68a";
    ctx.beginPath();
    ctx.ellipse(x + w / 2, y, 8, 6, 0, 0, Math.PI * 2);
    ctx.fill();
  }
}
