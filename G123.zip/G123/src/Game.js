import { Farmer } from "./Farmer.js";
import { Crop } from "./Crop.js";
import { Scarecrow, Crow } from "./Obstacle.js";
import { PowerUp } from "./PowerUp.js";
import { State, clamp, aabb, lerp, rnd } from "./utils.js";

/**
 * Game orchestrates loop, entities, HUD, multi-level flow, and config loading (G3).
 */
export class Game {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {{scoreEl?:HTMLElement,timeEl?:HTMLElement,goalEl?:HTMLElement,statusEl?:HTMLElement,powerEl?:HTMLElement,levelEl?:HTMLElement}} hud
   */
  constructor(canvas, hud = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.bounds = { w: canvas.width, h: canvas.height };
    this.aabb = aabb;

    // runtime state
    this.state = State.MENU;
    this.levelIndex = 0;   // 0..N-1
    this.level = 1;        // 1..N (HUD)
    this.score = 0;        // total across levels
    this.levelScore = 0;   // score in current level
    this.timeLen = 60;     // set per level
    this.timeLeft = this.timeLen;
    this.goal = 0;

    // world
    this.player = new Farmer(this.bounds.w / 2 - 17, this.bounds.h - 80);
    /** @type {Crop[]} */ this.crops = [];
    /** @type {Scarecrow[]} */ this.staticObstacles = [];
    /** @type {Crow[]} */ this.crows = [];
    /** @type {PowerUp[]} */ this.powerups = [];

    // spawners (set per level)
    this._accumCrop = 0;
    this._accumCrow = 0;
    this._accumPower = 0;
    this.spawnEveryBase = 0.9;
    this.crowEveryBase  = 6.0;
    this.powerEveryBase = 8.0;

    // power-ups
    this.activePower = null; this.powerTime = 0; this.scytheRadius = 0;

    // loop clock
    this.lastTime = 0;

    // HUD refs
    this.hud = {
      scoreEl: hud.scoreEl || null,
      timeEl: hud.timeEl || null,
      goalEl: hud.goalEl || null,
      statusEl: hud.statusEl || null,
      powerEl: hud.powerEl || null,
      levelEl: hud.levelEl || null,
    };

    // Input (defined at bottom)
    this.input = new Input(this);

    // Resize (bind so we can remove)
    this.onResize = this.onResize.bind(this);
    window.addEventListener("resize", this.onResize);

    // RAF loop as arrow → lexical `this`
    this.tick = (ts) => {
      const dt = Math.min((ts - this.lastTime) / 1000, 0.033);
      this.lastTime = ts;
      this.update(dt);
      this.render();
      requestAnimationFrame(this.tick);
    };

    // config will be loaded in init()
    this.levels = null;

    // optional: sharper pixel look for sprites
    if (this.ctx) this.ctx.imageSmoothingEnabled = false;
  }

  // ---------- G3: Config loading & normalization ----------

  /** Coerce & sanitize a level object → numbers (prevents NaN). */
  normalizeLevel(L) {
    const num = (v, def) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : def;
    };
    return {
      time:            num(L.time, 45),
      goal:            num(L.goal, 20),
      spawnEveryBase:  num(L.spawnEveryBase ?? L.spawnEvery, 0.9),
      crowEveryBase:   num(L.crowEveryBase, 6.0),
      powerEveryBase:  num(L.powerEveryBase, 8.0),
      extraScarecrows: num(L.extraScarecrows, 0),
    };
  }

  /** Load difficulty from config.json; call once before playing. */
  async init() {
    try {
      const res = await fetch("./config.json", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const cfg = await res.json();
      if (!cfg || !Array.isArray(cfg.levels) || cfg.levels.length === 0) throw new Error("Bad config");
      this.levels = cfg.levels.map(L => this.normalizeLevel(L));
    } catch (e) {
      console.warn("[Game] Failed to load config.json, using defaults:", e);
      this.levels = [
        this.normalizeLevel({ time:45, goal:20, spawnEveryBase:0.9, crowEveryBase:6.0, powerEveryBase:8.0, extraScarecrows:0 }),
        this.normalizeLevel({ time:45, goal:25, spawnEveryBase:0.6, crowEveryBase:4.5, powerEveryBase:7.0, extraScarecrows:1 }),
        this.normalizeLevel({ time:45, goal:30, spawnEveryBase:0.4, crowEveryBase:3.0, powerEveryBase:6.0, extraScarecrows:2 }),
      ];
    }
    // apply Level 1 while in MENU
    this.levelIndex = 0;
    this.applyLevelSettings();
    this.syncUI();
  }

  /** Apply current level settings and reset the round (score persists globally). */
  applyLevelSettings() {
    const L = this.normalizeLevel(this.levels[this.levelIndex] || {});
    this.level = this.levelIndex + 1;
    this.timeLen = L.time;
    this.goal = L.goal;
    this.timeLeft = this.timeLen;
    this.levelScore = 0;

    this.spawnEveryBase = L.spawnEveryBase;
    this.crowEveryBase  = L.crowEveryBase;
    this.powerEveryBase = L.powerEveryBase;

    // reset world
    this.player = new Farmer(this.bounds.w / 2 - 17, this.bounds.h - 80);
    this.crops.length = 0; this.crows.length = 0; this.powerups.length = 0;

    // base scarecrows + extras from config
    this.staticObstacles = [ new Scarecrow(200, 220), new Scarecrow(650, 160) ];
    for (let i = 0; i < L.extraScarecrows; i++) {
      const x = rnd(80, this.bounds.w - 110);
      const y = rnd(80, this.bounds.h - 140);
      this.staticObstacles.push(new Scarecrow(x, y));
    }

    // reset accumulators/powers
    this._accumCrop = this._accumCrow = this._accumPower = 0;
    this.activePower = null; this.powerTime = 0; this.scytheRadius = 0;

    if (this.hud.statusEl) this.hud.statusEl.textContent = `Level ${this.level}`;
  }

  // ---------- Controls & HUD ----------

  onResize() { /* fixed canvas; DPR support could go here */ }

  start() {
    if (this.state === State.MENU || this.state === State.GAME_OVER || this.state === State.WIN) {
      if (!this.levels) { console.warn("Config not loaded yet. Call game.init() first."); return; }
      this.applyLevelSettings();
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = `Level ${this.level} — Playing…`;
      requestAnimationFrame(this.tick);
    } else if (this.state === State.PAUSED) {
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = `Level ${this.level} — Playing…`;
    }
  }

  reset() {
    this.state = State.MENU;
    this.score = 0;
    this.levelIndex = 0;
    if (this.levels) this.applyLevelSettings();
    this.lastTime = performance.now();
    if (this.hud.statusEl) this.hud.statusEl.textContent = "Menu";
    this.syncUI();
  }

  togglePause() {
    if (this.state === State.PLAYING) {
      this.state = State.PAUSED;
      if (this.hud.statusEl) this.hud.statusEl.textContent = `Level ${this.level} — Paused`;
    } else if (this.state === State.PAUSED) {
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = `Level ${this.level} — Playing…`;
    }
  }

  /** Difficulty factor 0→1 as the level timer elapses. */
  getDifficulty() {
    const elapsed = this.timeLen - this.timeLeft;
    return clamp(elapsed / this.timeLen, 0, 1);
  }

  /** Update HUD text with safe numbers (no NaN). */
  syncUI() {
    const safe = v => Number.isFinite(v) ? v : 0;
    if (this.hud.scoreEl) this.hud.scoreEl.textContent = String(safe(this.score));
    if (this.hud.timeEl)  this.hud.timeEl.textContent  = Math.ceil(safe(this.timeLeft));
    if (this.hud.goalEl)  this.hud.goalEl.textContent  = String(safe(this.goal));
    if (this.hud.powerEl) this.hud.powerEl.textContent = this.activePower
      ? `${this.activePower} (${Math.ceil(safe(this.powerTime))}s)` : "—";
    if (this.hud.levelEl) this.hud.levelEl.textContent = String(safe(this.level));
  }

  // ---------- Spawners & effects ----------

  spawnCrop() {
    const r = Math.random();
    const type = r < 0.6 ? "wheat" : r < 0.9 ? "pumpkin" : "golden";
    const gx = Math.floor(Math.random() * ((this.bounds.w - 60) / 30)) * 30 + 30;
    const gy = Math.floor(Math.random() * ((this.bounds.h - 60) / 30)) * 30 + 30;
    this.crops.push(new Crop(gx, gy, type));
  }

  spawnCrow() {
    const x = Math.random() < 0.5 ? -20 : this.bounds.w + 20;
    const y = rnd(40, this.bounds.h - 40);
    const c = new Crow(x, y);
    const cx = this.bounds.w / 2 - c.x, cy = this.bounds.h / 2 - c.y, len = Math.hypot(cx, cy) || 1;
    const speed = rnd(70, 120) + this.getDifficulty() * 60;
    c.vx = (cx / len) * speed + rnd(-40, 40);
    c.vy = (cy / len) * speed + rnd(-30, 30);
    this.crows.push(c);
  }

  spawnPowerUp() {
    const type = Math.random() < 0.5 ? "speed" : "scythe";
    const x = rnd(40, this.bounds.w - 40), y = rnd(40, this.bounds.h - 40);
    this.powerups.push(new PowerUp(x, y, type));
  }

  applyPowerUp(type) {
    if (type === "speed") {
      this.activePower = "speed"; this.powerTime = 6;
      this.player.speed = this.player.baseSpeed * 1.7;
      this.scytheRadius = 0;
    } else {
      this.activePower = "scythe"; this.powerTime = 6;
      this.player.speed = this.player.baseSpeed;
      this.scytheRadius = 100;
    }
    this.syncUI();
  }

  updatePowerUpTimers(dt) {
    if (!this.activePower) return;
    this.powerTime -= dt;
    if (this.powerTime <= 0) {
      this.activePower = null;
      this.player.speed = this.player.baseSpeed;
      this.scytheRadius = 0;
    }
  }

  // ---------- Level flow ----------

  /** Advance to the next level or finish the campaign. */
  nextLevel() {
    if (this.levelIndex < this.levels.length - 1) {
      this.levelIndex += 1;
      this.applyLevelSettings();
      this.state = State.PLAYING;
      if (this.hud.statusEl) this.hud.statusEl.textContent = `Level ${this.level} — Playing…`;
    } else {
      this.state = State.WIN;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "All levels complete! You Win!";
    }
  }

  // ---------- Main update/render ----------

  update(dt) {
    if (this.state !== State.PLAYING) return;

    // timer
    this.timeLeft = clamp(this.timeLeft - dt, 0, this.timeLen);
    if (this.timeLeft <= 0) {
      this.state = State.GAME_OVER;
      if (this.hud.statusEl) this.hud.statusEl.textContent = "Time up! Game Over";
      this.syncUI();
      return;
    }

    // difficulty within current level
    const D = this.getDifficulty();
    const cropEvery  = lerp(this.spawnEveryBase, 0.25, D);
    const crowEvery  = lerp(this.crowEveryBase,  2.2,  D);
    const powerEvery = lerp(this.powerEveryBase, 4.0,  D);

    // player
    this.player.handleInput(this.input);
    this.player.update(dt, this); // method-call form keeps `this` inside Farmer

    // spawns
    this._accumCrop += dt;
    while (this._accumCrop >= cropEvery) { this._accumCrop -= cropEvery; this.spawnCrop(); }

    this._accumCrow += dt;
    while (this._accumCrow >= crowEvery) {
      this._accumCrow -= crowEvery;
      const maxCrows = Math.floor(1 + D * 4);
      if (this.crows.length < maxCrows) this.spawnCrow();
    }

    this._accumPower += dt;
    while (this._accumPower >= powerEvery) {
      this._accumPower -= powerEvery;
      if (this.powerups.length < 2) this.spawnPowerUp();
    }

    // crop collection (touch)
    const touches = this.crops.filter(c => aabb(this.player, c));
    if (touches.length) {
      touches.forEach(c => c.dead = true);
      const gained = touches.reduce((s, c) => s + c.points, 0);
      this.score += gained; this.levelScore += gained;
      if (this.levelScore >= this.goal) { this.nextLevel(); this.syncUI(); return; }
    }

    // scythe aura auto-collect
    if (this.activePower === "scythe" && this.scytheRadius > 0) {
      const px = this.player.x + this.player.w / 2, py = this.player.y + this.player.h / 2;
      this.crops.forEach(c => {
        const cx = c.x + c.w / 2, cy = c.y + c.h / 2;
        if (Math.hypot(px - cx, py - cy) <= this.scytheRadius) {
          c.dead = true; this.score += c.points; this.levelScore += c.points;
        }
      });
      if (this.levelScore >= this.goal) { this.nextLevel(); this.syncUI(); return; }
    }

    // power-up pickups
    this.powerups.forEach(p => { if (aabb(p, this.player)) { p.dead = true; this.applyPowerUp(p.type); } });

    // advance entities
    this.crows.forEach(c => c.update(dt, this));
    this.crops.forEach(c => c.update(dt, this));
    this.powerups.forEach(p => p.update(dt, this));

    // prune
    this.crops    = this.crops.filter(c => !c.dead);
    this.powerups = this.powerups.filter(p => !p.dead);

    // timers & HUD
    this.updatePowerUpTimers(dt);
    this.syncUI();
  }

  render() {
    const ctx = this.ctx; if (!ctx) return;
    ctx.clearRect(0, 0, this.bounds.w, this.bounds.h);

    // background grid
    ctx.fillStyle = "#dff0d5";
    ctx.fillRect(0, 0, this.bounds.w, this.bounds.h);
    ctx.strokeStyle = "#c7e0bd"; ctx.lineWidth = 1;
    for (let y = 30; y < this.bounds.h; y += 30) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.bounds.w, y); ctx.stroke(); }
    for (let x = 30; x < this.bounds.w; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.bounds.h); ctx.stroke(); }

    // draw entities
    this.crops.forEach(c => c.draw(ctx));
    this.powerups.forEach(p => p.draw(ctx));
    this.crows.forEach(c => c.draw(ctx));
    this.staticObstacles.forEach(o => o.draw(ctx));
    this.player.draw(ctx);

    // scythe aura ring
    if (this.activePower === "scythe" && this.scytheRadius > 0) {
      const px = this.player.x + this.player.w / 2, py = this.player.y + this.player.h / 2;
      ctx.strokeStyle = "rgba(245, 158, 11, 0.45)";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px, py, this.scytheRadius, 0, Math.PI * 2); ctx.stroke();
    }

    // state labels
    ctx.fillStyle = "#333";
    ctx.font = "16px system-ui, sans-serif";
    if (this.state === State.MENU) {
      ctx.fillText("Press Start to play (Level 1)", 20, 28);
    } else if (this.state === State.PAUSED) {
      ctx.fillText(`Level ${this.level} — Paused (press P to resume)`, 20, 28);
    } else if (this.state === State.GAME_OVER) {
      ctx.fillText("Time up! Press Reset to return to Menu", 20, 28);
    } else if (this.state === State.WIN) {
      ctx.fillText("All levels complete! Press Reset to play again", 20, 28);
    }
  }

  dispose() {
    this.input.dispose();
    window.removeEventListener("resize", this.onResize);
  }
}

/** Keyboard input manager with bound handlers (removable). */
class Input {
  /** @param {Game} game */
  constructor(game) {
    this.game = game;
    this.keys = new Set();
    this._onKeyDown = this.onKeyDown.bind(this); // bind so `this` is Input and removable
    this._onKeyUp   = this.onKeyUp.bind(this);
    window.addEventListener("keydown", this._onKeyDown);
    window.addEventListener("keyup", this._onKeyUp);
  }
  onKeyDown(e) { if (e.key === "p" || e.key === "P") this.game.togglePause(); this.keys.add(e.key); }
  onKeyUp(e)   { this.keys.delete(e.key); }
  dispose() {
    window.removeEventListener("keydown", this._onKeyDown);
    window.removeEventListener("keyup", this._onKeyUp);
  }
}
